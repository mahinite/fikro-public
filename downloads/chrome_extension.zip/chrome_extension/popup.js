const SERVER_URL = 'http://127.0.0.1:13457/add-idea';
const DATA_URL = 'http://127.0.0.1:13457/get-app-data';

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Auto-capture current tab URL
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url) {
            document.getElementById('link').value = tab.url;
        }
    } catch (e) {
        console.warn('URL capture ignored or unsupported outside browser context:', e);
    }

    // 2. Load patterns and workspaces from cache / fetch latest in real time
    await syncAppData();

    // 3. Check server status
    checkStatus();

    // 4. Hook input character counter
    const hookId = document.getElementById('hook');
    const hookCount = document.getElementById('hook-count');
    if (hookId && hookCount) {
        hookId.addEventListener('input', () => {
            const len = hookId.value.length;
            hookCount.textContent = `${len} / 120`;
            if (len > 100) {
                hookCount.style.color = 'var(--red)';
            } else {
                hookCount.style.color = 'var(--muted)';
            }
        });
    }

    // 5. Listen for workspace changes to persist preference in local storage
    const workspaceSelect = document.getElementById('workspace');
    if (workspaceSelect) {
        workspaceSelect.addEventListener('change', () => {
            localStorage.setItem('fikro_selected_workspace', workspaceSelect.value);
        });
    }

    // 6. Handle Save
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', saveIdea);
    }

    // 7. Keyboard shortcut (Enter to save)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            saveIdea();
        }
    });
});

async function syncAppData() {
    const patternSelect = document.getElementById('pattern');
    const workspaceSelect = document.getElementById('workspace');
    if (!patternSelect || !workspaceSelect) return;

    // 1. Instantly load cached patterns & workspaces from localStorage for a zero-flicker UI
    const cachedDataStr = localStorage.getItem('fikro_cached_app_data');
    if (cachedDataStr) {
        try {
            const cached = JSON.parse(cachedDataStr);
            if (cached) {
                if (Array.isArray(cached.patterns)) {
                    populatePatternsDropdown(patternSelect, cached.patterns);
                }
                if (Array.isArray(cached.workspaces)) {
                    populateWorkspacesDropdown(workspaceSelect, cached.workspaces);
                }
            }
        } catch (e) {
            console.error('Error parsing cached data:', e);
        }
    }

    // 2. Fetch fresh real-time workspace and pattern metadata asynchronously
    try {
        const response = await fetch(DATA_URL);
        if (response.ok) {
            const data = await response.json();
            if (data) {
                const currentPattern = patternSelect.value;
                const currentWorkspace = workspaceSelect.value;

                // Sync Patterns
                if (Array.isArray(data.patterns)) {
                    populatePatternsDropdown(patternSelect, data.patterns);
                    const patternExists = data.patterns.some(p => {
                        const name = typeof p === 'object' ? p.name : p;
                        return name === currentPattern;
                    });
                    if (patternExists) {
                        patternSelect.value = currentPattern;
                    }
                }

                // Sync Workspaces
                if (Array.isArray(data.workspaces)) {
                    populateWorkspacesDropdown(workspaceSelect, data.workspaces);

                    const savedWorkspaceSelection = localStorage.getItem('fikro_selected_workspace');
                    const hasSavedSelected = data.workspaces.some(w => w.id === savedWorkspaceSelection);
                    const hasAppActive = data.workspaces.some(w => w.id === data.active_workspace);

                    if (savedWorkspaceSelection && hasSavedSelected) {
                        workspaceSelect.value = savedWorkspaceSelection;
                    } else if (data.active_workspace && hasAppActive) {
                        workspaceSelect.value = data.active_workspace;
                    } else if (data.workspaces.length > 0) {
                        workspaceSelect.value = data.workspaces[0].id;
                    }
                }

                // Cache fresh synchronization locally
                localStorage.setItem('fikro_cached_app_data', JSON.stringify(data));
            }
        }
    } catch (err) {
        console.warn('Fikro application offline, utilizing caching layer:', err);
    }
}

function populatePatternsDropdown(selectEl, patternsList) {
    selectEl.innerHTML = '';
    patternsList.forEach(p => {
        const name = typeof p === 'object' ? p.name : p;
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        selectEl.appendChild(opt);
    });
    
    // Default fallback patterns in case of empty patterns
    if (selectEl.children.length === 0) {
        const fallbacks = ["Reflection", "Tutorial", "Story", "Other"];
        fallbacks.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            selectEl.appendChild(opt);
        });
    }
}

function populateWorkspacesDropdown(selectEl, workspacesList) {
    selectEl.innerHTML = '';
    workspacesList.forEach(w => {
        const opt = document.createElement('option');
        opt.value = w.id;
        opt.textContent = w.name;
        selectEl.appendChild(opt);
    });

    if (selectEl.children.length === 0) {
        const opt = document.createElement('option');
        opt.value = 'default';
        opt.textContent = 'My Ideas';
        selectEl.appendChild(opt);
    }
}

async function checkStatus() {
    const indicator = document.getElementById('status-indicator');
    if (!indicator) return;

    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 1000);
        
        await fetch('http://127.0.0.1:13457/status', { 
            method: 'OPTIONS', 
            signal: controller.signal 
        });
        
        indicator.classList.add('online');
        indicator.classList.remove('offline');
        indicator.title = 'Fikro App is connected';
        
        // Re-sync patterns and workspaces real-time on connection restoration
        syncAppData();
    } catch (err) {
        indicator.classList.add('offline');
        indicator.classList.remove('online');
        indicator.title = 'Fikro App is offline or unreachable';
    }
}

async function saveIdea() {
    const workspaceId = document.getElementById('workspace').value;
    const hook = document.getElementById('hook').value.trim();
    const topic = document.getElementById('topic').value.trim();
    const pattern = document.getElementById('pattern').value;
    const note = document.getElementById('note').value.trim();
    const link = document.getElementById('link').value;

    if (!hook) {
        showToast('⚠ Hook is required!');
        const hookInput = document.getElementById('hook');
        if (hookInput) hookInput.focus();
        return;
    }

    const saveBtn = document.getElementById('save-btn');
    if (!saveBtn) return;

    const originalContent = saveBtn.innerHTML;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span>Storing...</span>';

    try {
        const response = await fetch(SERVER_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                hook, 
                topic, 
                pattern, 
                note, 
                link,
                workspace_id: workspaceId
            })
        });

        if (response.ok) {
            showToast('✨ Idea stored successfully!');
            
            // Instantly sync fresh view state on workspace changes
            const hookInput = document.getElementById('hook');
            const noteInput = document.getElementById('note');
            const countInput = document.getElementById('hook-count');

            if (hookInput) hookInput.value = '';
            if (countInput) {
                countInput.textContent = '0 / 120';
                countInput.style.color = 'var(--muted)';
            }
            if (noteInput) noteInput.value = '';
            
            // Clean dismissal
            setTimeout(() => window.close(), 1200);
        } else {
            throw new Error('Server returned error');
        }
    } catch (err) {
        showToast('❌ Error: Is Fikro running?');
        console.error(err);
    } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = originalContent;
    }
}

function showToast(msg) {
    const toast = document.getElementById('toast');
    if (toast) {
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2500);
    }
}
